from flask import Flask, render_template, request, redirect, url_for
from train_scheduling.dp_solver import DPSolver
from train_scheduling.train_model import TrainSchedule, Train
from train_scheduling.config import CONFIG
import json
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = './uploads'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return redirect(url_for('index'))
    
    file = request.files['file']
    if file.filename == '':
        return redirect(url_for('index'))
    
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)

    schedule = TrainSchedule()
    with open(file_path, 'r') as f:
        train_data = json.load(f)
        for train_info in train_data['trains']:
            train = Train(train_info['id'], train_info['arrival'], train_info['departure'], train_info['is_fixing'])
            schedule.add_train(train)

    solver = DPSolver(schedule, CONFIG)
    solver.solve()

    return render_template('results.html', schedule=schedule)

if __name__ == "__main__":
    app.run(debug=True)