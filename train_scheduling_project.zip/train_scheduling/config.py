CONFIG = {
    'min_headway': 1,
    'max_headway': 5,
    'min_dwell_time': 1,
    'max_dwell_time': 3,
    'transfer_time': 2,
    'total_time': 24
}